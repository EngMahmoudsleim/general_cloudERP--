<?php

return [
    'name' => 'Accounting',
    'module_version' => '1.0',
    'pid' => 16,
];
