<?php

return [
    'ageingreport'=>'Ageing Balance Report',
 
    'view'=>'View Balance Ageing Report',
    
   
    //news

];