<?php

return [
    'name' => 'fieldforce',
    'module_version' => "1.5",
    'pid' => 5,
    'lic1' => 'aHR0cHM6Ly9sLnBubi5zb2x1dGlvbnMvYXBpL3R5cGVfMQ==',

];

