<?php


// -- You dont have any permissions for resale, change, modified this files !
// -- Any requests you can contact me on : 
// -- WhatsApp https://wa.me/6288297510999 
// -- Email dreamcasters666@gmail.com

return [
    'name' => 'WhatsApp',
    'module_version' => '1.1',
    'author' => 'DreamCasters',
    'pid' => 910,
    'app_desc' => 'WhatsApp Notification Notifications For UltimatePOS',
    'version' => '1.1'
];