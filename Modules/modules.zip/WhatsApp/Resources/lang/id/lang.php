<?php

return [
'app_name' => 'WhatsApp Gateway',
'connect_to_apps' => 'Connect WhatsApp Accounts'
];