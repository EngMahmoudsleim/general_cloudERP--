<?php
return [

    'creat'=>'Add New',
    'edit'=>'Edit Data',
    'delete'=>'Delete Data',
    'update'=>'Update Data',
];
