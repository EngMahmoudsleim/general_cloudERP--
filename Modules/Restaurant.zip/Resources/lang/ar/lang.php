<?php
return [
'restaurant'=>'إدارة المطاعم',
'submen1'=>'submen 1',
'submen2'=>'submen 2',
'submen3'=>'submen 3',
'creat'=>'إضافة',
'edit'=>'تعديل',
'delete'=>'حذف',
'update'=>'تحديث',
];
