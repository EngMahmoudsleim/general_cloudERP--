<?php

return [
    'name' => 'Restaurant',
    'module_version' => "1.0",
    'pid' => 6

];
