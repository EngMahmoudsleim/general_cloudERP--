<?php

return [
    'name' => 'Hms',
    'module_version' => '2.2',
    'pid' => '18',
];
