<?php

return [
    'name' => 'Crm',
    'module_version' => '3.0',
    'pid' => 7,
];
