<?php

return [
    'name' => 'AiAssistance',
    'module_version' => '1.3',
    'pid' => 17,
];
