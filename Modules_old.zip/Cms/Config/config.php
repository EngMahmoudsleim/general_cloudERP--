<?php

return [
    'name' => 'Cms',
    'module_version' => '2.0',
    'pid' => 15,
];
