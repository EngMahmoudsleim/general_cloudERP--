<?php

return [
    'connector_module' => 'د نښلونکی ماډل',
    'connector' => 'نښلونکی ',
    'create_client' => 'پیرودونکی رامینځته کړئ',
    'client_secret' => 'پیرودونکی راز',
    'clients' => 'پیرودونکي',
    'documentation' => 'اسناد',
];
